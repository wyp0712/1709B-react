import React, { Component } from 'react'
// import PropTypes from 'prop-types'
import axios from 'axios'
import './mock/index'
import NavList from './components/navList'
import MovieList from './components/movieList'

export default class App extends Component {
  state = {
    navList: ['正在上映','即将上映'],
    tabIndex: 0,
    movieData: []
  }

  render() {
    return (
      <div>
        <NavList 
          navList={this.state.navList}
          tabEvent={(index) => this.handleTabClick(index)}
        />
        <MovieList 
          movieData={this.state.movieData}
          tabIndex={this.state.tabIndex}
        />
      </div>
    )
  }

  componentDidMount() {
    axios.get('/api/list').then(res => {
      console.log(res.data.movie, 'res')
      this.setState({
        movieData: res.data.movie
      })
    })
  }


  handleTabClick = (index) => {
    this.setState({
      tabIndex: index
    })
  }


}
