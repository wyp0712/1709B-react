import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class navList extends Component {
  static propTypes = {
    // prop: PropTypes
    navList: PropTypes.array
  }

  render() {
    return (
      <div>
        {
          this.props.navList.map((item,index) => {
            return <h1 onClick={() => this.handleTabClick(index)} key={index}>{item}</h1>
          })
        }
      </div>
    )
  }

  handleTabClick = (index) => {
    const { tabEvent } = this.props;
    tabEvent(index)
  }
}
