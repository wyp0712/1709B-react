import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class movieList extends Component {
  static propTypes = {
    movieData: PropTypes.array,
    tabIndex: PropTypes.number
  }

  render() {
    return (
      <ul>
      {
        this.props.movieData.map((item, index) => {
          if (item.flag && this.props.tabIndex === 0) {
            return <li key={index}>
              <img src={item.img} alt=''/>
              {item.name}
            </li>
          } else if (!item.flag && this.props.tabIndex === 1) {
            return <li key={index}>
              <img src={item.img} alt=''/>
              {item.name}
            </li>
          } else {
            return null;
          }
        }) 
      }
    </ul>
    )
  }
}
