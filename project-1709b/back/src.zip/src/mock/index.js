import Mock from 'mockjs';
import movieData from './data.json';

Mock.mock('/api/list', movieData)
