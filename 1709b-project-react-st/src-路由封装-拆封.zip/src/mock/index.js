import Mock from 'mockjs';
import data from './music.json';

Mock.mock('/api/music', data);

// const obj = {
//   name: 1
// }

/**
 * import from '';
 * 
 * export  
 * export default
 */

// export { obj };

