import React, { Component } from 'react'

export default class componentName extends Component {
  render() {
    return (
      <div>
        登陆
      </div>
    )
  }
}
