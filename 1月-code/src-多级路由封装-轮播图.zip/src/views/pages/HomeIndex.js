import React, { Component } from 'react'
import Swiper from '../../components/Swiper'
export default class componentName extends Component {
  render() {
    return (
      <div>
        home-首页
        <Swiper />

        
      </div>
    )
  }
}
