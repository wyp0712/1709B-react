import React, { Component } from 'react'

import RouterView from '../../router/index'

export default class componentName extends Component {
  render() {
    return (
      <div>
        home
        {/* 二级路由 */}
        <RouterView routes={this.props.routes}></RouterView>
      </div>
    )
  }
}
