import React, { Component } from 'react'
import { connect } from 'react-redux'


class HomeCart extends Component {
  render() {
    const { cartData, handleAddCart,handleRemoveCart } = this.props;
    return (
      <div className='app-home'>
        {
          cartData.map((item,index) => {
            return <ul key={index}>
               <li> <img src={item.img} alt=''/> </li>
               <li>
                  <span
                   onClick={ () => handleRemoveCart(index) }
                  > - </span>
                  <span>{item.count}</span>
                  <span
                   onClick={ () => handleAddCart(index) }
                  >+</span>
                </li>
            </ul>
          })
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    cartData: state.cartData 
  }
}

const mapActionToProps = (dispatch) => {
  return {
    // 添加给购物车
    handleAddCart(index) {
      const action = {
        type: 'add_cart',
        index
      }
      dispatch(action)
    },
    handleRemoveCart(index) {
      const action = {
        type: 'remove_cart',
        index
      }
      dispatch(action)
    }


  }
}

export default connect(mapStateToProps, mapActionToProps)(HomeCart)
