import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class btnCom extends Component {
  // static propTypes = {
  //   // prop: PropTypes
  // }

  state = {
    list: ['1','2','3'],
    num: 0
  }

  render() {
    return (
      <div className='dice-com'>
        {
          this.state.list.map((item, index) => {
            return <span key={index}
             onClick={ () => this.handleBtnEvent(index) }
            >{item}</span>
          })
        }
      </div>
    )
  }

  componentDidMount() {
    this.handleBtnEvent()
  }

  handleBtnEvent = (index) => {
    const { diceEvent } = this.props;
    setTimeout(() => {
      const num = Math.floor(Math.random()* 100)
      console.log(num, '点击的时候执行定时器')
      diceEvent(num)
    })
  }
}
