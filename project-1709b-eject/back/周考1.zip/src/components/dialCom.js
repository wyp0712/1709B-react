import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class dialCom extends Component {
  static propTypes = {
    // prop: PropTypes
  }

  state = {
    list: ['50','100','200','300'],
    count: []
  }

  render() {
    return (
      <div className='dial-com'>
        <div className='left'>
          {
            this.state.list.map((item, index) => {
              return <span key={index}
               onClick={() => this.bindMoneyBtn(item)}
              >{item}</span>
            })
          }
        </div>
        <div className='right'>
          <span className='circle'>
            { this.getTotalPrice() }
          </span>
        </div>
      </div>
    )
  }

  getTotalPrice () {
    return this.state.count.reduce((n, next) => {
      return n + next * 1
    }, 0)
  }

  bindMoneyBtn = (item) => {
     const { totalPrice } = this.props;

     const list = [...this.state.count] 
     list.push(item)
     this.setState({
        count: list
     }, () => {
      // console.log(this.state.count, 'count')
      // console.log(this.getTotalPrice(), '0000')
      totalPrice(this.getTotalPrice())

     })
  }
}
