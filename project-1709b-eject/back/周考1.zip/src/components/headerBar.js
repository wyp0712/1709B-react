import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class headerBar extends Component {
  static propTypes = {
    // state
  }
  state = {
    count: 1000
  }
  render() {
    return (
      <div className='app-header'>
        <span>金额：{this.state.count}</span>
      </div>
    )
  }
}
