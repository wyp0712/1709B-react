import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class btnCom extends Component {
  // static propTypes = {
  //   // prop: PropTypes
  // }

  state = {
    list: ['大','豹子','小']
  }

  render() {
    return (
      <div className='btn-com'>
        {
          this.state.list.map((item, index) => {
            return <span key={index}
             onClick={ () => this.handleBtnEvent(index) }
            >{item}</span> 
          })
        }
      </div>
    )
  }


  handleBtnEvent = (index) => {
    const { btnEvent } = this.props;
    btnEvent(index)

  }
}
