import React, { Component } from 'react'
import axios from 'axios'
import './mock/index'
import HeaderBar from './components/headerBar'
import Dice from './components/diceCom' // 骰子组件
import Dial from './components/dialCom' // 转盘
import Btn from './components/btnCom' // 按钮组件

// context 组件通信

export default class App extends Component {

  state = {
    movieData: [],
    totalNum: 0,
    totalFlag: null,
  }

  render() {
    return (
      <div>
        {/* 头部 */}
        <HeaderBar
          headerEvent={ () => {} }
        />

        {/* 骰子  */}

        <Dice
         diceEvent={ (dianshu) => this.getDice(dianshu) }
        />

        {/* 转盘 */}
        <Dial 
         totalPrice={ (num) => this.getPrice(num) }
        />

        {/* 按钮点击 */}
        <Btn
         btnEvent={ (flag) => this.getBtnFlag(flag) }
        />
      </div>
    )
  }

  getPrice = (num) => {
    // console.log(num, '我在父组件中接收总价')
    this.setState({
      totalNum: num
    })
  }

  getDice = (num) => {
    console.log(num, 'num我在父组件中获取到的点数')
  }

  getBtnFlag = (flag) => {
    console.log(flag, '我是父组件中接收的状态值')
    this.setState({
      totalFlag: flag
    }, () => {
      console.log('我向让另一个组件动')
      this.getDice()
    }) 
  }

  componentDidMount() {

  }



}
